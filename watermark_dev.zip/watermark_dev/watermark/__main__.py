from PIL import Image, ImageDraw, ImageFont
import random
import argparse

def main():
    argp = argparse.ArgumentParser(
        description='Generate a unique watermark.',
        epilog='Example: python3 watermark image.png watermark.png --save --show --text="Hello World!"')    
    argp.add_argument('image', help='Filename of image to convert.', type=str)
    argp.add_argument('watermark', help='Filename of watermark background.', type=str)
    argp.add_argument('--text', help='The text to use for the watermark. Default: ""', action='store', default="")
    argp.add_argument('--save', help='Save the image. Default: False.', action='store_true', default=False)
    argp.add_argument('--show', help='Show the image once complete. Default: False.', action='store_true', default=False)
    argp.add_argument('--debug', help='Show padding reference lines. Default: False.', action='store_true', default=False)
    argp.add_argument('--alpha', help='The alpha channel for the watermark, range (0-255). Default: 150', type=int, default=150)
    argp.add_argument('--font_size', help='The font-size to use for the watermark. Default: 20', type=int, default=20)
    argp.add_argument('--font', help='The font to use for the watermark. Default: "FreeSans-1Zge.otf" (Included)', action='store', default="FreeSans-1Zge.otf")
    args, leftovers = argp.parse_known_args()
    doWatermark(args)    
    return 0

def doWatermark(args):
    
    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)
    a = 255

    fill_color = (r,g,b,a)
    padding_fill_color = (0,200,0,255)
    centered_fill_color = (200,0,0,255)
    wm_padding_fill_color = (0,0,200,255)

    #prompt for your text and image (set to vars for ease of use during testing)
    textToMark      = args.text
    #textToMark     = input("Enter text: ")
    #imagePath      = input("Enter image path to watermark: ")
    imagePath       = args.image
    watermarkPath   = args.watermark
    fontSize        = args.font_size
    font            = ImageFont.truetype(args.font, fontSize)

    # Set to True to show helpful reference lines.
    SHOW_REFERENCE_LINES = args.debug

    # Open Images
    img         = Image.open(imagePath)
    print ("[+] Opening image: " + imagePath)
    print ("[+] Image size: " + str(img.size))
    
    # check if image is png or jpg
    if imagePath.endswith(".png"):
        img = img.convert("RGBA")
    
    watermarkBg = Image.open(watermarkPath).convert("RGBA")
    print ("[+] Opening watermark: " + imagePath)
    print ("[+] Watermark size: " + str(img.size))    
    
    watermarkBg.alpha_composite(watermarkBg)
    print("[+] Watermark alpha_composite successful")
    


    # Watermark padding
    x = int(img.size[0] / 4) + random.randint(int(-int(img.size[0] / 4) / 2), int(img.size[0] / 4) / 2)
    y = int(img.size[1] / 4) + random.randint(int(-int(img.size[1] / 4) / 2), int(img.size[1] / 4) / 2)
    print ("[+] Watermark padding: " + str(x) + "," + str(y))

    # Padding, visualized.
    if SHOW_REFERENCE_LINES:
        draw = ImageDraw.Draw(img)
        
        # Watermark padding, relative to the bg image.
        draw.line((0, 0, 0, y), fill=wm_padding_fill_color, width=4)
        draw.line((0, y, x, y), fill=wm_padding_fill_color, width=4)
        draw.line((x, y, x, img.size[1]), fill=wm_padding_fill_color, width=4)
        
        # draw vertical line inside the padding on the right
        draw.line((img.size[0] - x, y, img.size[0] - x, img.size[1]), fill=wm_padding_fill_color, width=4)
        draw.line((x, y, x, img.size[0]), fill=wm_padding_fill_color, width=4)
        draw.line((x, img.size[1], img.size[0], img.size[1]), fill=wm_padding_fill_color, width=4)
        draw.line((img.size[0], img.size[1], img.size[0], y), fill=wm_padding_fill_color, width=4)
        draw.line((img.size[0], y, 0, y), fill=wm_padding_fill_color, width=4)
        draw.line((0, 0, 0, 0), fill=wm_padding_fill_color, width=4)
        draw.line((0, 0, img.size[0], 0), fill=wm_padding_fill_color, width=4)
        draw.line((img.size[0], 0, img.size[0], img.size[1]), fill=wm_padding_fill_color, width=4)
        draw.line((img.size[0], img.size[1], 0, img.size[1]), fill=wm_padding_fill_color, width=4)
        draw.line((0, img.size[1], 0, img.size[1]), fill=wm_padding_fill_color, width=4)
        draw.line((0, 0, 0, img.size[1]), fill=wm_padding_fill_color, width=4)
        draw.line((0, img.size[0], 0, img.size[1]), fill=wm_padding_fill_color, width=4)
        
        # Image Resolution
        draw.line((0, 0, img.size[0], img.size[1]), fill=padding_fill_color, width=4)
        draw.line((img.size[0], 0, 0, img.size[1]), fill=padding_fill_color, width=4)
        
        
    # Appropriate size for watermark, anti-aliased. This may be a little off, but it's close enough.
    watermarkBg = watermarkBg.resize( (round(img.size[0] / 2), round(watermarkBg.size[1] / 2)), resample=Image.ANTIALIAS)
    print("[+] Watermark resized to: " + str(watermarkBg.size))

    # Center the text in the watermark
    wm_x = ( (watermarkBg.size[0]) / 4 )  + ( (watermarkBg.size[0] / 2) / 2 ) - ( (len(textToMark) * 10) / 2 )
    wm_y = ( (watermarkBg.size[1]) / 4 )  + ( (watermarkBg.size[1] / 2) / 2 ) - ( (fontSize * 2) / 2 ) + (fontSize / 2)
    
    # Draw text on watermark
    if (len(textToMark) > 0):
        draw = ImageDraw.Draw(watermarkBg)
        draw.text((wm_x, wm_y), textToMark, fill=fill_color, font=font)
    print("[+] Watermark text drawn")

    if SHOW_REFERENCE_LINES:
        # Watermark Text padding & Watermark Resolution
        lines = [
            (0, wm_x, wm_y, 0),
            (watermarkBg.size[0], watermarkBg.size[1], 0, 0)
        ]
        for line in lines:
            draw.line(line, fill=centered_fill_color, width=1)
        
    watermarkBg.putalpha(args.alpha)
    print("[+] Watermark alpha set to: " + str(args.alpha))
        
    # Rotate the watermark
    angle = random.choice([-45, -30, 30, 45])
    watermarkBg = watermarkBg.rotate(angle, expand=1)
    print("[+] Rotating watermark by: " + str(angle) + " degrees")

    img.paste(watermarkBg, (x, y), watermarkBg)
    print("[+] Watermark pasted")
    
    if (args.save):
        extension = imagePath.split(".")[-1]
        complete = args.image.replace('.', '_')+ "_watermark" + "." + extension
        img.save(complete)
        print("Saved watermarked image to: " + complete)
        
    if (args.show):    
        img.show() 

if __name__ == "__main__":
    exit(main())